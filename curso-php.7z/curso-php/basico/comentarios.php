<div class="titulo">Comentarios PHP</div>

<?php
    echo("Estou no PHP")
    // echo("Comentario")
    # echo("Comentario")
// ?>

<p>Depois do primeiro bloco</p>

<!-- <p>Comentario HTML</p> -->

<?php
    /*
        linha 1 do comentario
        linha 2 do comentario
        linha 3 do comentario  
        ?> 
    */
 ?>

    <p>Depois do segundo bloco</p>

