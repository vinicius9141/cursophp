<div class="titulo">Olá PHP</div>
<h2>Exemplo A</h2>
<?php
    echo("Olá , Mundo <br>");
    echo('Mundo');
    ?>

    <h2>Exemplo B </h2>

<?= "Outra forma de inserir PHP na pagina Web (Para imprimir diretamente)"?>
<?= 2 * 3 + 3?>

<?php

phpinfo();