<div class="titulo">Operações Aritmeticas</div>


<?php

    echo (1 + 1) , "<BR>";
    var_dump (1 + 1.0);
    echo ("<br>");
    echo (1 + 2.5), "<BR>";
    echo (10 - 2) , "<BR>";
    echo (2 * 5), "<BR>";
    echo (7 / 4), "<BR>";
    echo intdiv(7 , 4), "<BR>"; //Ignora as cadas decimais 
    echo round (7 / 4), "<BR>"; //Arredonda o valor
    echo (7 % 4), "<BR>";//resto da divisão
    echo (7 % 2), "<BR>";
    echo (8 % 4), "<BR>";
    echo (7 / 0.00000001), "<BR>";
    // echo intdiv (7 , 0); //Erro
    echo (4 ** 2), "<BR>"; // exponencial
    
    // Precedencia de operadores:
    // () => ** => * % => + - 

    echo ("<p> Precedencia</p>");

    echo (2 + 3 * 4), "<BR>";
    echo ((2 + 3) * 4), "<BR>";
    echo (2 + 3 * 4 ** 2), "<BR>";
    echo (((2 + 3) * 4) ** 2), "<BR>";
    