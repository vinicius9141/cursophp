<div class="titulo">Tipo String</div>

<?php 
    echo "Eu sou uma string";
    echo "<BR>";
    var_dump ("Eu também");
    echo "<BR>";

    //concatenação

    echo ("Nós também ") . ("Somos");
    echo ("<BR>") , ("Também aceito ") , ("Virgulas");
    echo ("<BR>");

    echo ("'Teste '") . ('"Teste"');

    print("<BR>") . ("Função print além do echo");


    //algumas funções 


    echo ("<BR>") . (strtoupper('maximixado'));
    echo ("<BR>") . (strtolower('MINIMIZADO'));
    echo ("<BR>") . (ucfirst('só a primeira letra'));
    echo ("<BR>") . (ucwords('todas as palavras'));
    echo ("<BR>") . (strlen('quantas letras?'));
    echo ("<BR>") . (mb_strlen('Eu também',"utf-8"));
    echo ("<BR>") . (substr('Só uma parte mesmo' , 7 , 6 )); // Primeiro numero é onde começa a contar e o ultimo é até onde vai partindo do inicio
    echo ("<BR>") . (str_replace('isso' , 'aquilo' , 'trocar isso'));// primeira palavra em '' é a que vai ser substituida e a segunda é o valor que sera colocado no lugar 
    

?>