<div class="titulo">Tipo Float</div>

<?php

    echo (1.1) , "<br>";
    var_dump(1.0);
    echo ("<br>");

    echo PHP_FLOAT_MAX , "<BR>";
    echo PHP_FLOAT_MIN ,"<BR>";
    echo (1.2e3) , "<br>"; //1200 (1.2*3zeros)
    echo (13E-3) , "<BR>"; //0.013 