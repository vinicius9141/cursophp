<div class="titulo">Desafio Predecedencia</div>

<?php
    echo ("<p>1. Qual o valor sera impresso?</p>");
    echo (2 + 5 * 3 + (12 / 6) / (-8 ** 3));

    echo ("<p>2. Qual expressão imprime o valor 100? </p> <BR>");
    echo ("A "), ((1 + 2) * 20 - 15), "<BR>";
    echo ("B "), (4 * 5 ** 2), "<BR>";
    echo ("C "), (2 ** 3 ** 4 / 1e25), "<BR>";
    echo ("D "), (3 + (3 + 8 ) / 2 - 3), "<BR>";
?>
