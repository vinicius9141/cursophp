<div class="titulo">Desafio String</div>

<?php 
    echo (strpos('AbcaBcabC' , ' abc'));
    echo (stripos('!AbcaBcabC' , 'abc'));
?>