const nomeReal = "Ellen Kelly";

var nomeusr = window.prompt ("Qual sei nome?");

if (nomeReal == nomeusr){
    window.alert("Parabéns você foi a escolhida pra entrar no meu coração ")
    window.location.href ="https://staticr1.blastingcdn.com/media/photogallery/2017/6/12/660x290/b_502x220/um-homem-apaixonado-revela-o-seu-verdadeiro-amor-em-8-formas-dicasonlinetv_1382239.jpg"
}else{
    window.alert("Sai daqui mermão ")
    window.location.href="https://www.youtube.com/watch?v=MkRed9gokYM"
}