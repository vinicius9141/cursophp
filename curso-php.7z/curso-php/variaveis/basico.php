<div class="titulo">Variaveis</div>

<?php
    $numeroA = 13;
    echo ($numeroA);
    echo("<br>");
    var_dump($numeroA);
    echo("<br>");
    $a = 3;
    $b = 16;
    $soma = $a + $b;
    echo($soma);
    echo("<br>");
    
    echo (isset($soma));
    unset($soma);
    echo(isset($soma));
    echo ("<br>");
    var_dump($soma);

    $variavel = 10;
    echo("<br>") . ($variavel);

    $variavel = "Agora sou uma string";

    echo("<br>") . ($variavel);

    echo ("<br>");
    var_dump($_SERVER["HTTP_HOST"]);
?>